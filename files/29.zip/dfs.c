/* Aug 22, 2026 */
/* Perform DFS traversal and determine the articulation points in a unigraph */
/* Print out the visit order and finish order */

#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int vertex;
    struct Node *next;
} Node;

#define MIN(a, b) ((a) < (b) ? (a) : (b))

/* Create a new linked-list node */
Node *createNode(int vertex)
{
    Node *newNode = (Node *)malloc(sizeof(Node));

    if (newNode == NULL) {
        printf("Memory allocation error.\n");
        exit(1);
    }

    newNode->vertex = vertex;
    newNode->next = NULL;

    return newNode;
}


/* Add vertex v to the end of an adjacency list */
void appendNode(Node **head, int v)
{
    Node *newNode = createNode(v);

    if (*head == NULL) {
        *head = newNode;
        return;
    }

    Node *current = *head;

    while (current->next != NULL) {
        current = current->next;
    }
    
    current->next = newNode;
}


/* Add an undirected edge (u, v) */
void addEdge(Node *adjList[], int u, int v)
{
    appendNode(&adjList[u], v); 
    appendNode(&adjList[v], u);
}


/* Print the adjacency list */
void printAdjList(Node *adjList[], int N)
{
    int i;

    printf("Adjacency List:\n");

    for (i = 1; i <= N; i++) {

        Node *current = adjList[i];

        printf("%d: ", i);

        while (current != NULL) {
            printf("%d ", current->vertex);
            current = current->next;
        }

        printf("\n");
    }
}


/*
   Recursive DFS.

   visitOrder records the order in which nodes
   are first discovered.

   finishOrder records the order in which DFS
   finishes processing each node.
*/
void DFS(Node *adjList[],
         int u,
         int is_visited[],
         int visitOrder[],
         int *visitCount,
         int finishOrder[],
         int *finishCount,
         int lowest[], int discover[], int isAP[], int numChild[], int parent[])
{
    Node *current;

    /* Mark node u as visited */
    is_visited[u] = 1;


    /* Record visit order */
    visitOrder[*visitCount] = u;
    (*visitCount)++;

    /* Initialize discover and lowest */
    lowest[u] = *visitCount;
    discover[u] = *visitCount;
    numChild[u] = 0;
    isAP[u] = 0;

    /* Examine all neighbors of u */
    current = adjList[u];

    while (current != NULL) {

        int w = current->vertex;

        if (!is_visited[w]) {

            parent[w] = u;
            numChild[u] = numChild[u]+1;

            DFS(adjList,
                w,
                is_visited,
                visitOrder,
                visitCount,
                finishOrder,
                finishCount,
                lowest, discover, isAP, numChild, parent);
            
            lowest[u] = MIN(lowest[u], lowest[w]);
            
            /* u is the root with two or more children */
            if ((discover[u] == 1) && (numChild[u] >= 2)){
              isAP[u] = 1;
            }
            /* u is an internal node and its children cannot reach any ancester of u. */
            if ((discover[u] > 1) && (discover[u] <= lowest[w])){
              isAP[u] = 1;
            }
        }
        else if (w != parent[u])
          lowest[u] = MIN(lowest[u], discover[w]);

        current = current->next;
    }

    /* Record finish order */
    finishOrder[*finishCount] = u;
    (*finishCount)++;
}


/* Perform DFS over all nodes */
void DFS_Traversal(Node *adjList[], int N)
{
    int *is_visited; /* */
    int *visitOrder;
    int *finishOrder;

    int visitCount = 0;
    int finishCount = 0;

    int i;
    int *isAP, *discover, *lowest, *numChild, *parent; 

    is_visited = (int *)calloc(N + 1, sizeof(int)); /* Allocate and initialize to 0*/
    visitOrder = (int *)malloc(N * sizeof(int));
    finishOrder = (int *)malloc(N * sizeof(int));

    isAP = (int *)calloc(N + 1, sizeof(int)); /* Allocate and initialize to 0*/
    discover = (int *)malloc(N+1 * sizeof(int));
    lowest = (int *)malloc(N+1 * sizeof(int));
    numChild = (int *)malloc(N+1 * sizeof(int));
    parent = (int *)malloc(N+1 * sizeof(int));

    if (is_visited == NULL || visitOrder == NULL || finishOrder == NULL ||
        isAP == NULL || discover == NULL || lowest == NULL || numChild == NULL || parent == NULL) {
        printf("Memory allocation error.\n");
        exit(1);
    }

    /*
       Start DFS from node 1, then check nodes
       2, 3, ..., N. This also handles a
       disconnected graph.
    */
    for (i = 1; i <= N; i++) {
        if (!is_visited[i]) {
            DFS(adjList,
                i,
                is_visited,
                visitOrder,
                &visitCount,
                finishOrder,
                &finishCount,
                lowest, discover, isAP, numChild, parent);
        }
    }

    printf("\nVisit order:  ");

    for (i = 0; i < visitCount; i++) {
        printf("%d ", visitOrder[i]);
    }

    printf("\nFinish order: ");

    for (i = 0; i < finishCount; i++) {
        printf("%d ", finishOrder[i]);
    }

    printf("\n");

    printf("\nArticulation points: ");
    for (i = 0; i < N; i++) {
        if(isAP[i] > 0)
          printf("%d ", i);
    }

    printf("\n");

    free(is_visited);
    free(visitOrder);
    free(finishOrder);
    free(isAP);
    free(discover);
    free(lowest);
    free(numChild);
    free(parent);
}


/* Free all adjacency lists */
void freeAdjList(Node *adjList[], int N)
{
    int i;

    for (i = 1; i <= N; i++) {

        Node *current = adjList[i];

        while (current != NULL) {

            Node *temp = current;
            current = current->next;

            free(temp);
        }
    }
}


int main(int argc, char *argv[])
{
    FILE *file;

    Node **adjList;

    int N;
    int u, v;
    int i;

    if (argc != 2) {
        printf("Usage: %s <input_file>\n", argv[0]);
        return 1;
    }

    file = fopen(argv[1], "r");

    if (file == NULL) {
        printf("Cannot open input file.\n");
        return 1;
    }

    /* Read number of nodes */
    if (fscanf(file, "%d", &N) != 1 || N <= 0) {
        printf("Invalid number of nodes.\n");
        fclose(file);
        return 1;
    }

    /*
       Create adjacency list.
       Index 0 is unused because node labels
       are 1, 2, ..., N.
    */
    adjList = (Node **)calloc((N + 1), sizeof(Node *));

    if (adjList == NULL) {
        printf("Memory allocation error.\n");
        fclose(file);
        return 1;
    }

    /* Initialize all adjacency lists to empty */
    for (i = 1; i <= N; i++) {
        adjList[i] = NULL;
    }

    /* Read edges until end of file. All node labels must be between 1 and N. 
    */
    while (fscanf(file, "%d %d", &u, &v) == 2) {
        if (u < 1 || u > N || v < 1 || v > N) {
            printf("Invalid edge: (%d, %d)\n", u, v);
            continue;
        }
        addEdge(adjList, u, v);
    }

    fclose(file);

    printAdjList(adjList, N);

    DFS_Traversal(adjList, N);

    freeAdjList(adjList, N);
    free(adjList);

    return 0;
}