#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

/*
 * An edge in the adjacency list.
 *
 * capacity = capacity of this edge
 * flow     = current flow on this edge
 * rev      = corresponding reverse edge in residual network
 * next     = next edge in adjacency list
 *
 * original = 1 if this edge came from the input file
 *            0 if it is a residual reverse edge
 */
typedef struct Edge {
    int from;
    int to;

    long long capacity;
    long long flow;

    int original;

    struct Edge *rev;
    struct Edge *next;
} Edge;


/*
 * Add a directed edge:
 *
 *      u ----capacity----> v
 *
 * and its residual reverse edge:
 *
 *      v -------0-------> u
 */
int add_edge(Edge **adj, int u, int v, long long capacity)
{
    Edge *forward = malloc(sizeof(Edge));
    Edge *reverse = malloc(sizeof(Edge));

    if (forward == NULL || reverse == NULL) {
        free(forward);
        free(reverse);
        return 0;
    }

    /* Forward edge */
    forward->from = u;
    forward->to = v;
    forward->capacity = capacity;
    forward->flow = 0;
    forward->original = 1;
    forward->rev = reverse; /* Link to the reverse edge */

    forward->next = NULL;
    if (adj[u] == NULL) {
        adj[u] = forward;
    } else {
        Edge *p = adj[u];

        while (p->next != NULL) {
            p = p->next;
        }

        p->next = forward;
    }


    /* Reverse residual edge */
    reverse->from = v;
    reverse->to = u;
    reverse->capacity = 0;
    reverse->flow = 0;
    reverse->original = 0;
    reverse->rev = forward; /* Link to the forward edge */

    reverse->next = NULL;

    if (adj[v] == NULL) {
        adj[v] = reverse;
    } else {
        Edge *p = adj[v];

        while (p->next != NULL) {
            p = p->next;
        }

        p->next = reverse;
    }
 
    return 1;
}

/*
 * BFS on the residual network.
 *
 * parent[v] stores the edge used to reach node v.
 *
 * An edge can be used if:
 *
 *      residual capacity = capacity - flow > 0
 */
int bfs(Edge **adj,
        int N,
        int source,
        int sink,
        Edge **parent,
        int *visited,
        int *queue)
{
    int front = 0;
    int rear = 0;

    memset(parent, 0, N * sizeof(Edge *));
    memset(visited, 0, N * sizeof(int));

    queue[rear++] = source;
    visited[source] = 1;

    while (front < rear) {

        int u = queue[front++];

        Edge *e = adj[u];

        while (e != NULL) {

            long long residual = e->capacity - e->flow;

            if (residual > 0 && !visited[e->to]) {

                visited[e->to] = 1;
                parent[e->to] = e;

                if (e->to == sink) {
                    return 1;
                }

                queue[rear++] = e->to;
            }

            e = e->next;
        }
    }

    return 0;
}


/*
 * Ford-Fulkerson using BFS.
 *
 * Since BFS is used to find the augmenting path,
 * this is the Edmonds-Karp algorithm.
 */
int edmonds_karp(Edge **adj,
                 int N,
                 int source,
                 int sink,
                 long long *max_flow)
{
    Edge **parent;
    int *visited;
    int *queue;

    parent = malloc(N * sizeof(Edge *));
    visited = malloc(N * sizeof(int));
    queue = malloc(N * sizeof(int));

    if (parent == NULL || visited == NULL || queue == NULL) {
        free(parent);
        free(visited);
        free(queue);
        return 0;
    }

    long long total_flow = 0;

    /*
     * Repeatedly find an augmenting path using BFS.
     */
    while (bfs(adj,
               N,
               source,
               sink,
               parent,
               visited,
               queue)) {

        /*
         * Find the bottleneck capacity of the path.
         */
        long long path_flow = LLONG_MAX;

        int v = sink;

        while (v != source) {

            Edge *e = parent[v];

            long long residual =
                e->capacity - e->flow;

            if (residual < path_flow) {
                path_flow = residual;
            }

            v = e->from;
        }

        /*
         * Augment the flow along the path.
         */
        v = sink;

        while (v != source) {

            Edge *e = parent[v];

            e->flow += path_flow;

            /*
             * Increase reverse residual capacity.
             *
             * Since the reverse edge has capacity 0,
             * making its flow negative gives:
             *
             * residual = 0 - (-flow)
             */
            e->rev->flow -= path_flow;

            v = e->from;
        }

        /*
         * Check for integer overflow.
         */
        if (total_flow > LLONG_MAX - path_flow) {
            fprintf(stderr, "Maximum flow is too large.\n");

            free(parent);
            free(visited);
            free(queue);

            return 0;
        }

        total_flow += path_flow;
    }

    free(parent);
    free(visited);
    free(queue);

    *max_flow = total_flow;

    return 1;
}


/*
 * Print the adjacency list.
 *
 * Only original edges are printed here.
 */
void print_adjacency_list(Edge **adj, int N)
{
    printf("\nAdjacency list:\n");

    for (int u = 0; u < N; u++) {

        printf("%d:", u);

        Edge *e = adj[u];

        while (e != NULL) {

            if (e->original) {
                printf(" -> %d(cap=%lld)",
                       e->to,
                       e->capacity);
            }

            e = e->next;
        }

        printf("\n");
    }
}


/*
 * Print the flow assigned to every original edge.
 */
void print_edge_flows(Edge **adj, int N)
{
    printf("\nFlow on each edge:\n");

    for (int u = 0; u < N; u++) {

        Edge *e = adj[u];

        while (e != NULL) {

            if (e->original) {

                printf("%d -> %d : flow = %lld / capacity = %lld\n",
                       e->from,
                       e->to,
                       e->flow,
                       e->capacity);
            }

            e = e->next;
        }
    }
}


/*
 * Free every edge in the adjacency lists.
 */
void free_adjacency_list(Edge **adj, int N)
{
    for (int u = 0; u < N; u++) {

        Edge *e = adj[u];

        while (e != NULL) {

            Edge *next = e->next;

            free(e);

            e = next;
        }
    }

    free(adj);
}


int main(int argc, char *argv[])
{
    if (argc != 2) {

        fprintf(stderr,
                "Usage: %s input_file\n",
                argv[0]);

        return EXIT_FAILURE;
    }


    /*
     * Open input file.
     */
    FILE *fp = fopen(argv[1], "r");

    if (fp == NULL) {
        perror("Cannot open input file");
        return EXIT_FAILURE;
    }


    /*
     * Read number of nodes.
     */
    int N;

    if (fscanf(fp, "%d", &N) != 1) {

        fprintf(stderr,
                "Error: cannot read number of nodes.\n");

        fclose(fp);

        return EXIT_FAILURE;
    }

    if (N < 2) {

        fprintf(stderr,
                "Error: N must be at least 2.\n");

        fclose(fp);

        return EXIT_FAILURE;
    }


    /*
     * adj[u] points to the first edge leaving node u.
     *
     * This is the adjacency list.
     */
    Edge **adj = calloc(N, sizeof(Edge *));

    if (adj == NULL) {

        fprintf(stderr,
                "Error: memory allocation failed.\n");

        fclose(fp);

        return EXIT_FAILURE;
    }


    /*
     * Read the edges.
     *
     * Each remaining line contains:
     *
     *      u v capacity
     */
    int u;
    int v;
    long long capacity;

    while (1) {

        int result =
            fscanf(fp, "%d %d %lld",
                   &u,
                   &v,
                   &capacity);

        /*
         * Normal end of file.
         */
        if (result == EOF) {
            break;
        }

        /*
         * Every edge must contain exactly
         * three values.
         */
        if (result != 3) {

            fprintf(stderr,
                    "Error: invalid edge specification.\n");

            fclose(fp);
            free_adjacency_list(adj, N);

            return EXIT_FAILURE;
        }

        /*
         * Check node labels.
         */
        if (u < 0 || u >= N ||
            v < 0 || v >= N) {

            fprintf(stderr,
                    "Error: invalid edge (%d, %d).\n"
                    "Node labels must be from 0 to %d.\n",
                    u,
                    v,
                    N - 1);

            fclose(fp);
            free_adjacency_list(adj, N);

            return EXIT_FAILURE;
        }

        /*
         * Capacities cannot be negative.
         */
        if (capacity < 0) {

            fprintf(stderr,
                    "Error: edge capacity cannot be negative.\n");

            fclose(fp);
            free_adjacency_list(adj, N);

            return EXIT_FAILURE;
        }

        /*
         * Add forward and reverse residual edges.
         */
        if (!add_edge(adj, u, v, capacity)) {

            fprintf(stderr,
                    "Error: memory allocation failed.\n");

            fclose(fp);
            free_adjacency_list(adj, N);

            return EXIT_FAILURE;
        }
    }

    fclose(fp);


    /*
     * Source = 0
     * Sink   = N - 1
     */
    int source = 0;
    int sink = N - 1;


    print_adjacency_list(adj, N);


    /*
     * Compute maximum flow.
     */
    long long max_flow;

    if (!edmonds_karp(adj,
                      N,
                      source,
                      sink,
                      &max_flow)) {

        fprintf(stderr,
                "Error computing maximum flow.\n");

        free_adjacency_list(adj, N);

        return EXIT_FAILURE;
    }


    printf("\nSource = %d\n", source);
    printf("Sink   = %d\n", sink);

    printf("\nMaximum flow = %lld\n",
           max_flow);


    print_edge_flows(adj, N);


    free_adjacency_list(adj, N);

    return EXIT_SUCCESS;
}